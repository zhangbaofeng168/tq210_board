
void init_lcd();
void draw_pixel(int x, int y, unsigned int color);
void clear_screen();
void draw_line(int x0, int y0, int x1, int y1, unsigned int color);
void draw_circle(int x, int y, int r, unsigned int color);