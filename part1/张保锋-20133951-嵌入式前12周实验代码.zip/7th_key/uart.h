void uart_init();
char getc(void);
void putc(unsigned char c);
void put_string(unsigned char *str);
