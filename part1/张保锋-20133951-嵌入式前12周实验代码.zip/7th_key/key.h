
void init_key();